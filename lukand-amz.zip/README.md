# lukand-amz

Repositório de redirecionamentos seguros para links de afiliado da Amazon.

## Como usar

1. Faça login no GitHub com o usuário **tecninfel-debug**.
2. Crie um repositório público chamado **lukand-amz**.
3. Envie o conteúdo desta pasta para o repositório.
4. Vá em **Settings → Pages → Source** e selecione `main` (branch) e `/ (root)`.
5. Após salvar, a página ficará disponível em:
   ```
   https://tecninfel-debug.github.io/lukand-amz/
   ```

## Estrutura
- `/oferta/ryzen5/` → redireciona para https://amzn.to/3JAFBBw  
- `/oferta/modelo/` → base para novos redirecionamentos

## Criando novos redirecionamentos
1. Copie a pasta `/oferta/modelo/` e renomeie (ex: `/oferta/memoria16gb/`).
2. Edite o arquivo `index.html` e substitua o texto **COLOQUE_SEU_LINK_AQUI** pelo link da Amazon.
3. Faça commit e push para o GitHub.
4. O novo link será acessível por:
   ```
   https://tecninfel-debug.github.io/lukand-amz/oferta/memoria16gb/
   ```

## Segurança
- Nenhum dado de origem (referer) é enviado à Amazon.
- Código protegido contra troca de tag por sites intermediários.
